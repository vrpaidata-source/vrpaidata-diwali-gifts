VRPAIData Diwali Gifts 2026 — GitHub Pages starter

FILES
- index.html: responsive Tamil landing page

IMPORTANT BEFORE PUBLISHING
1. Update the contest start/end dates, prize value, eligibility, winner-selection method, and contact details.
2. Confirm applicable local rules/permissions for offering and delivering fireworks as a prize.
3. This static page does not save registrations, verify social follows, or select winners.
4. Never request OTPs, passwords, UPI PINs, or bank details.
5. The Instagram button points to https://www.instagram.com/vrpaidata/ and the Facebook button uses the supplied share link.

PUBLISH ON GITHUB
1. Sign in at https://github.com
2. Create a new public repository named: vrpaidata-diwali-gifts
3. Upload index.html to the repository root and commit the file.
4. Open Settings -> Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select branch main and folder /(root), then Save.
7. Wait for the published link shown in Settings -> Pages. It usually looks like:
   https://YOUR-GITHUB-USERNAME.github.io/vrpaidata-diwali-gifts/

The exact live URL depends on your GitHub username and repository settings.
